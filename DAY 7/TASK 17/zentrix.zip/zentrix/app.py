from fastapi import FastAPI
from pydantic import BaseModel

import joblib
import pandas as pd
import numpy as np

# ------------------------------------------------
# LOAD MODEL FILES
# ------------------------------------------------

model = joblib.load('model/risk_prediction_model.pkl')
tfidf = joblib.load('model/tfidf_vectorizer.pkl')
scaler = joblib.load('model/scaler.pkl')
label_encoder = joblib.load('model/label_encoder.pkl')
feature_columns = joblib.load('model/feature_columns.pkl')

# ------------------------------------------------
# FASTAPI APP
# ------------------------------------------------

app = FastAPI(title="Zentrix AI Backend")

# ------------------------------------------------
# INPUT FORMAT
# ------------------------------------------------

class WorkerInput(BaseModel):
    age: int
    department: str
    shift_duration_hrs: float
    reported_symptoms: str
    ppe_compliance_score: float
    audio_alert_flag: str

# ------------------------------------------------
# HOME ROUTE
# ------------------------------------------------

@app.get("/")
def home():
    return {
        "message": "Zentrix AI Backend Running"
    }

# ------------------------------------------------
# PREDICTION ROUTE
# ------------------------------------------------

@app.post("/predict")
def predict(data: WorkerInput):
    # TEXT FEATURE
    text_vector = tfidf.transform([data.reported_symptoms]).toarray()

    # Preprocess categorical inputs to match training schema
    audio_numeric = 1 if data.audio_alert_flag.strip().lower() == 'yes' else 0

    # Create temporary DataFrame with the raw structured input
    raw_df = pd.DataFrame({
        'age': [data.age],
        'shift_duration_hrs': [data.shift_duration_hrs],
        'ppe_compliance_score': [data.ppe_compliance_score],
        'audio_alert_flag': [audio_numeric],
        'department': [data.department]
    })

    # One-hot encode the categorical columns in the input
    encoded_df = pd.get_dummies(raw_df)

    # Reindex columns to match training schema (filling missing columns with 0, dropping extra columns)
    structured_df = encoded_df.reindex(columns=feature_columns, fill_value=0)

    # SCALE FEATURES
    structured_scaled = scaler.transform(structured_df)

    # COMBINE FEATURES
    final_input = np.hstack((structured_scaled, text_vector))

    # PREDICTION
    prediction = model.predict(final_input)
    predicted_label = label_encoder.inverse_transform(prediction)

    return {
        "Predicted Risk Level": predicted_label[0]
    }
