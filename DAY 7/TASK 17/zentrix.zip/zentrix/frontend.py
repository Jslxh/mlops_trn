import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import requests
import datetime
import time

# ------------------------------------------------
# PAGE CONFIGURATION
# ------------------------------------------------
st.set_page_config(
    page_title="Zentrix AI - Enterprise Safety & Health Platform",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ------------------------------------------------
# SESSION STATE INITIALIZATION
# ------------------------------------------------
if 'prediction_history' not in st.session_state:
    # Initialize with some realistic historical records
    st.session_state.prediction_history = [
        {
            "worker_id": "W-8931",
            "age": 42,
            "department": "Foundry",
            "shift_duration_hrs": 11.5,
            "ppe_compliance_score": 0.45,
            "audio_alert_flag": "Yes",
            "reported_symptoms": "severe heat exhaustion, dizziness, nausea",
            "risk_level": "HIGH",
            "timestamp": "2026-05-24 14:15:32"
        },
        {
            "worker_id": "W-1284",
            "age": 28,
            "department": "Assembly Line",
            "shift_duration_hrs": 8.0,
            "ppe_compliance_score": 0.95,
            "audio_alert_flag": "No",
            "reported_symptoms": "no symptoms, routine checkup",
            "risk_level": "LOW",
            "timestamp": "2026-05-24 15:30:11"
        },
        {
            "worker_id": "W-4820",
            "age": 35,
            "department": "Heavy Machinery",
            "shift_duration_hrs": 10.0,
            "ppe_compliance_score": 0.70,
            "audio_alert_flag": "No",
            "reported_symptoms": "mild back pain from heavy lifting",
            "risk_level": "MEDIUM",
            "timestamp": "2026-05-24 16:42:05"
        },
        {
            "worker_id": "W-7491",
            "age": 51,
            "department": "Chemical Processing",
            "shift_duration_hrs": 8.5,
            "ppe_compliance_score": 0.85,
            "audio_alert_flag": "No",
            "reported_symptoms": "slight skin irritation, minor rash",
            "risk_level": "MEDIUM",
            "timestamp": "2026-05-24 17:10:44"
        }
    ]

if 'live_logs' not in st.session_state:
    st.session_state.live_logs = [
        "[18:05:12] SYSTEM: Core AI Inference engine loaded successfully.",
        "[18:10:32] API: Handshake established with FastAPI port 8000.",
        "[18:15:32] EVENT: High Risk Alert triggered for Worker W-8931 in Foundry. Alert escalated.",
        "[18:22:01] REGULATION: PPE Compliance Sweep initiated for Paint Shop.",
        "[18:30:11] EVENT: Safe state confirmed for Worker W-1284 in Assembly Line."
    ]

# ------------------------------------------------
# BACKEND HEALTH PING
# ------------------------------------------------
BACKEND_URL = "http://127.0.0.1:8000"

def check_backend():
    try:
        r = requests.get(f"{BACKEND_URL}/", timeout=1.5)
        if r.status_code == 200:
            return True, "Online"
    except Exception:
        pass
    return False, "Offline"

backend_ok, backend_status_text = check_backend()

# ------------------------------------------------
# CUSTOM ENTERPRISE CSS (CYBERPUNK / GLASSMORPHISM)
# ------------------------------------------------
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap');
    
    /* Background adjustments */
    html, body, [data-testid="stAppViewContainer"], [data-testid="stHeader"] {
        font-family: 'Outfit', sans-serif;
        background-color: #0b0f19 !important;
        color: #f1f5f9;
    }
    
    /* Hide default Streamlit styling */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {background-color: transparent !important;}
    
    /* Glassmorphism Cards */
    .glass-card {
        background: rgba(16, 23, 41, 0.6);
        border-radius: 12px;
        border: 1px solid rgba(0, 240, 255, 0.12);
        box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.35);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        padding: 24px;
        margin-bottom: 24px;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .glass-card:hover {
        border-color: rgba(0, 240, 255, 0.28);
        box-shadow: 0 12px 40px 0 rgba(0, 240, 255, 0.08);
        transform: translateY(-2px);
    }

    /* Glow titles */
    .glow-title {
        font-size: 2.8rem;
        font-weight: 800;
        letter-spacing: 2px;
        background: linear-gradient(90deg, #ff7b00 0%, #00f0ff 50%, #ff0055 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-shadow: 0 0 30px rgba(0, 240, 255, 0.15);
        margin-bottom: 5px;
    }
    
    .glow-subtitle {
        font-size: 1.15rem;
        color: #8fa0ba;
        font-weight: 400;
        letter-spacing: 1px;
        margin-bottom: 25px;
    }

    /* Metric Cards Grid */
    .metric-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 16px;
        margin-bottom: 25px;
    }

    .metric-card {
        background: rgba(22, 30, 52, 0.55);
        border: 1px solid rgba(255, 255, 255, 0.06);
        border-radius: 10px;
        padding: 16px;
        position: relative;
        overflow: hidden;
        transition: transform 0.2s ease;
    }
    
    .metric-card:hover {
        transform: scale(1.02);
    }
    
    .metric-card::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 4px;
        height: 100%;
    }
    
    .metric-card.blue::before { background-color: #00f0ff; }
    .metric-card.orange::before { background-color: #ff7b00; }
    .metric-card.red::before { background-color: #ff0055; }
    .metric-card.green::before { background-color: #00ff88; }
    
    .metric-val {
        font-size: 1.85rem;
        font-weight: 700;
        margin: 5px 0;
        font-family: 'JetBrains Mono', monospace;
    }
    
    .metric-lbl {
        font-size: 0.8rem;
        color: #94a3b8;
        text-transform: uppercase;
        font-weight: 600;
        letter-spacing: 0.5px;
    }

    /* Status Dot Animation */
    .status-dot {
        height: 10px;
        width: 10px;
        border-radius: 50%;
        display: inline-block;
        margin-right: 8px;
    }
    
    .dot-active {
        background-color: #00ff88;
        box-shadow: 0 0 10px #00ff88;
        animation: pulse-green 1.8s infinite alternate;
    }
    
    .dot-warning {
        background-color: #ff7b00;
        box-shadow: 0 0 10px #ff7b00;
        animation: pulse-orange 1.8s infinite alternate;
    }

    .dot-danger {
        background-color: #ff0055;
        box-shadow: 0 0 10px #ff0055;
        animation: pulse-red 1.8s infinite alternate;
    }
    
    @keyframes pulse-green {
        0% { transform: scale(0.9); opacity: 0.6; }
        100% { transform: scale(1.2); opacity: 1; }
    }
    @keyframes pulse-orange {
        0% { transform: scale(0.9); opacity: 0.6; }
        100% { transform: scale(1.2); opacity: 1; }
    }
    @keyframes pulse-red {
        0% { transform: scale(0.9); opacity: 0.6; }
        100% { transform: scale(1.2); opacity: 1; }
    }

    /* Alert Displays */
    .alert-panel {
        border-radius: 12px;
        padding: 24px;
        margin: 15px 0;
        border: 1px solid transparent;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
    }
    
    .alert-low {
        background: rgba(0, 255, 136, 0.08);
        border-color: rgba(0, 255, 136, 0.35);
        color: #00ffaa;
    }
    
    .alert-medium {
        background: rgba(255, 123, 0, 0.08);
        border-color: rgba(255, 123, 0, 0.35);
        color: #ff9d42;
    }
    
    .alert-high {
        background: rgba(255, 0, 85, 0.08);
        border-color: rgba(255, 0, 85, 0.35);
        color: #ff477e;
    }
    
    /* Code logs terminal format */
    .terminal-output {
        font-family: 'JetBrains Mono', monospace;
        background-color: #05070c;
        border: 1px solid rgba(255, 255, 255, 0.05);
        padding: 15px;
        border-radius: 6px;
        font-size: 0.85rem;
        color: #38bdf8;
        line-height: 1.6;
        height: 250px;
        overflow-y: scroll;
    }
</style>
""", unsafe_allow_html=True)

# ------------------------------------------------
# SIDEBAR NAVIGATION
# ------------------------------------------------
st.sidebar.markdown(
    """
    <div style='text-align: center; margin-bottom: 20px;'>
        <h2 style='color: #00f0ff; font-weight: 800; letter-spacing: 2px; margin-bottom:0;'>ZENTRIX AI</h2>
        <span style='color: #ff7b00; font-size:0.75rem; text-transform:uppercase; font-weight:600; letter-spacing:1.5px;'>Worker Risk Intel</span>
        <hr style='border-color: rgba(0,240,255,0.15); margin-top: 15px;'>
    </div>
    """,
    unsafe_allow_html=True
)

tab_selection = st.sidebar.radio(
    "NAVIGATION HUB",
    [
        "Dashboard", 
        "Risk Prediction", 
        "Live Monitoring", 
        "Analytics Suite", 
        "Prediction History", 
        "System Health Hub", 
        "Platform Overview"
    ]
)

st.sidebar.markdown("<br><hr style='border-color: rgba(0,240,255,0.15);'>", unsafe_allow_html=True)

# Backend Status Indicator in Sidebar
status_badge = '<span class="status-dot dot-active"></span> <b style="color:#00ff88;">ONLINE</b>' if backend_ok else '<span class="status-dot dot-danger"></span> <b style="color:#ff0055;">OFFLINE</b>'
st.sidebar.markdown(
    f"""
    <div style='background: rgba(30, 41, 59, 0.4); border-radius: 8px; padding: 12px; border: 1px solid rgba(255,255,255,0.05);'>
        <div style='font-size:0.75rem; color:#8fa0ba; text-transform:uppercase; font-weight:700;'>FastAPI Core</div>
        <div style='font-size:1.0rem; margin-top:5px;'>{status_badge}</div>
        <div style='font-size:0.7rem; color:#64748b; margin-top:5px; font-family:"JetBrains Mono";'>{BACKEND_URL}</div>
    </div>
    """,
    unsafe_allow_html=True
)

# ------------------------------------------------
# HERO HEADER SECTION
# ------------------------------------------------
st.markdown("<div class='glow-title'>🛡️ ZENTRIX AI</div>", unsafe_allow_html=True)
st.markdown("<div class='glow-subtitle'>Predictive Industrial Worker Safety & Risk Intelligence System</div>", unsafe_allow_html=True)

# ------------------------------------------------
# TAB 1: DASHBOARD
# ------------------------------------------------
if tab_selection == "Dashboard":
    
    # KPI metrics row (HTML grid injection)
    alerts_count = sum(1 for p in st.session_state.prediction_history if p["risk_level"] == "HIGH")
    avg_ppe = np.mean([p["ppe_compliance_score"] for p in st.session_state.prediction_history]) * 100 if st.session_state.prediction_history else 92.5
    
    st.markdown(
        f"""
        <div class="metric-grid">
            <div class="metric-card blue">
                <div class="metric-lbl">Workers Monitored</div>
                <div class="metric-val">1,248</div>
                <div style="font-size: 0.75rem; color: #00ff88;">↑ 4.2% active shift increases</div>
            </div>
            <div class="metric-card red">
                <div class="metric-lbl">Active High Risk Alerts</div>
                <div class="metric-val">{alerts_count}</div>
                <div style="font-size: 0.75rem; color: #ff0055;">Escalated to safety officers</div>
            </div>
            <div class="metric-card green">
                <div class="metric-lbl">PPE Compliance Score</div>
                <div class="metric-val">{avg_ppe:.1f}%</div>
                <div style="font-size: 0.75rem; color: #00ff88;">Within target regulations</div>
            </div>
            <div class="metric-card orange">
                <div class="metric-lbl">Safety Model Precision</div>
                <div class="metric-val">97.8%</div>
                <div style="font-size: 0.75rem; color: #ff7b00;">XGBoost + TF-IDF Stack</div>
            </div>
            <div class="metric-card blue">
                <div class="metric-lbl">Telemetry Latency</div>
                <div class="metric-val">12ms</div>
                <div style="font-size: 0.75rem; color: #00f0ff;">Realtime ingestion latency</div>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )
    
    # Layout splits
    c1, c2 = st.columns([3, 2], gap="large")
    
    with c1:
        st.markdown("<div class='glass-card'><h3>📊 Shift Incident & Risk Heatmap</h3>", unsafe_allow_html=True)
        # Scatterplot for Shift Fatigue vs PPE Compliance
        np.random.seed(42)
        sim_data = pd.DataFrame({
            'Shift Duration (Hrs)': np.random.uniform(4.0, 16.0, 100),
            'PPE Compliance Score': np.random.uniform(0.3, 1.0, 100),
            'Predicted Risk': np.random.choice(['LOW', 'MEDIUM', 'HIGH'], size=100, p=[0.6, 0.3, 0.1]),
            'Worker Age': np.random.randint(18, 65, 100)
        })
        # Set high risk conditions in mock data
        sim_data.loc[sim_data['Shift Duration (Hrs)'] > 12.0, 'Predicted Risk'] = 'HIGH'
        sim_data.loc[sim_data['PPE Compliance Score'] < 0.5, 'Predicted Risk'] = 'HIGH'
        
        fig = px.scatter(
            sim_data,
            x='Shift Duration (Hrs)',
            y='PPE Compliance Score',
            color='Predicted Risk',
            size='Worker Age',
            color_discrete_map={'LOW': '#00ff88', 'MEDIUM': '#ff7b00', 'HIGH': '#ff0055'},
            template='plotly_dark'
        )
        fig.update_layout(
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            xaxis=dict(showgrid=True, gridcolor='rgba(255,255,255,0.05)'),
            yaxis=dict(showgrid=True, gridcolor='rgba(255,255,255,0.05)'),
            margin=dict(l=20, r=20, t=10, b=20)
        )
        st.plotly_chart(fig, use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)
        
    with c2:
        st.markdown("<div class='glass-card'><h3>📡 Realtime System Logs</h3>", unsafe_allow_html=True)
        # Log terminal output styling
        log_html = "".join([f"<div>{l}</div>" for l in st.session_state.live_logs])
        st.markdown(f"<div class='terminal-output'>{log_html}</div>", unsafe_allow_html=True)
        
        # Action shortcuts
        st.markdown("<br><b>Quick Escapes / Action Checklist</b>", unsafe_allow_html=True)
        st.checkbox("Escalate Foundry W-8931 Critical Alert to Site Safety Director", value=True)
        st.checkbox("Request mandatory medical evaluation for Shift #4 workers", value=False)
        st.markdown("</div>", unsafe_allow_html=True)

    # Secondary row
    st.markdown("<div class='glass-card'><h3>⚡ Active Operational Risk Overview</h3>", unsafe_allow_html=True)
    c_a, c_b, c_c = st.columns(3)
    
    with c_a:
        # Weekly incident bar graph
        days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        incidents = [12, 18, 9, 21, 14, 28, 16]
        fig_week = px.bar(
            x=days, y=incidents, labels={'x': 'Day', 'y': 'Safety Alerts'},
            title='Total Security Alerts (Last 7 Days)', template='plotly_dark'
        )
        fig_week.update_traces(marker_color='#00f0ff')
        fig_week.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', margin=dict(t=35, b=20, l=10, r=10))
        st.plotly_chart(fig_week, use_container_width=True)
        
    with c_b:
        # Department incidents distribution donut
        deps = ['Manufacturing', 'Foundry', 'Heavy Machinery', 'Assembly', 'Chemicals', 'Logistics']
        vals = [24, 38, 15, 10, 32, 12]
        fig_donut = px.pie(
            names=deps, values=vals, hole=0.5,
            title='Incident Distribution by Sector', template='plotly_dark'
        )
        fig_donut.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', margin=dict(t=35, b=20, l=10, r=10))
        st.plotly_chart(fig_donut, use_container_width=True)
        
    with c_c:
        # Gauge compliance
        fig_g = go.Figure(go.Indicator(
            mode = "gauge+number",
            value = avg_ppe,
            title = {'text': "Average Compliance Rating (%)"},
            gauge = {
                'axis': {'range': [0, 100], 'tickwidth': 1, 'tickcolor': "white"},
                'bar': {'color': "#00f0ff"},
                'bgcolor': "rgba(0,0,0,0)",
                'borderwidth': 2,
                'bordercolor': "rgba(255,255,255,0.08)",
                'steps': [
                    {'range': [0, 60], 'color': 'rgba(255, 0, 85, 0.25)'},
                    {'range': [60, 85], 'color': 'rgba(255, 123, 0, 0.25)'},
                    {'range': [85, 100], 'color': 'rgba(0, 255, 136, 0.25)'}
                ],
            }
        ))
        fig_g.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', margin=dict(t=50, b=20, l=10, r=10), font={'color': "white", 'family': "Outfit"})
        st.plotly_chart(fig_g, use_container_width=True)
        
    st.markdown("</div>", unsafe_allow_html=True)

# ------------------------------------------------
# TAB 2: RISK PREDICTION FORM
# ------------------------------------------------
elif tab_selection == "Risk Prediction":
    st.markdown("<div class='glass-card'><h3>🔮 Run Automated ML Risk Prediction</h3>", unsafe_allow_html=True)
    
    col_input, col_sim = st.columns([3, 2], gap="large")
    
    with col_input:
        st.write("Provide worker biometric telemetry and environmental compliance ratings below:")
        
        # Form Container
        with st.form("inference_form"):
            w_id = st.text_input("Worker Identifier Code", value="W-5412")
            
            f_c1, f_c2 = st.columns(2)
            with f_c1:
                age = st.number_input("Worker Age (Years)", min_value=18, max_value=85, value=38)
                department = st.selectbox(
                    "Department Sector",
                    [
                        "Assembly Line", "Boiler Room", "Chemical Processing", 
                        "Electrical Unit", "Foundry", "Heavy Machinery", 
                        "Mining Section", "Paint Shop", "Warehouse", "Welding Unit"
                    ]
                )
            with f_c2:
                shift_duration = st.slider("Active Shift Duration (Hours)", min_value=1.0, max_value=16.0, value=8.0, step=0.5)
                audio_alert = st.selectbox("Audio Hazard Alert Triggered?", ["No", "Yes"])
                
            ppe_score = st.slider("PPE Compliance Score (0.0 to 1.0)", min_value=0.0, max_value=1.0, value=0.92, step=0.01)
            reported_symptoms = st.text_area("Worker Symptoms / Logs Note", placeholder="Enter symptoms (e.g. 'feeling dizzy due to extreme high furnace heat, minor head pain')")
            
            submit_btn = st.form_submit_button("🔮 INITIATE BIOMETRIC AI ASSESSMENT")
            
    with col_sim:
        st.write("<b>Platform Status Diagnostics</b>", unsafe_allow_html=True)
        if backend_ok:
            st.success("🤖 Core Inference System is connected directly to FastAPI app.")
        else:
            st.warning("⚠️ FastAPI Backend API is offline. Running in deterministic Fallback Simulation Mode.")
            
        st.markdown(
            """
            <div style='background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.05); padding:15px; border-radius:8px;'>
                <h5>Multimodal Inference Pipeline</h5>
                <ul>
                    <li>Structured columns aligned using <b>feature_columns.pkl</b>.</li>
                    <li>Biometrics scaled via fitted <b>StandardScaler</b>.</li>
                    <li>Symptom semantics evaluated using <b>TF-IDF Vectorizer</b>.</li>
                    <li>Outputs resolved via <b>Logistic Regression</b> estimator.</li>
                </ul>
            </div>
            """,
            unsafe_allow_html=True
        )

    # Process Form Submission
    if submit_btn:
        payload = {
            "age": int(age),
            "department": department,
            "shift_duration_hrs": float(shift_duration),
            "reported_symptoms": reported_symptoms if reported_symptoms.strip() else "none",
            "ppe_compliance_score": float(ppe_score),
            "audio_alert_flag": audio_alert
        }
        
        # Placeholder while computing
        with st.spinner("Processing multimodal features..."):
            pred_success = False
            risk_level = "UNKNOWN"
            confidence = 0.94 # Mock confidence
            
            if backend_ok:
                try:
                    res = requests.post(f"{BACKEND_URL}/predict", json=payload, timeout=5)
                    if res.status_code == 200:
                        res_json = res.json()
                        risk_level = res_json.get("Predicted Risk Level", "UNKNOWN").upper()
                        pred_success = True
                except Exception as e:
                    st.error(f"Error during backend communication: {e}")
            
            # Fallback Simulation if backend offline or fails
            if not pred_success:
                # Deterministic fallback rules for demonstration
                symptom_str = reported_symptoms.lower()
                high_keywords = ['dizzy', 'heat', 'chest pain', 'exhaustion', 'injury', 'nausea', 'vomit', 'burn']
                med_keywords = ['pain', 'ache', 'cough', 'rash', 'fatigue', 'tired']
                
                has_high_keyword = any(k in symptom_str for k in high_keywords)
                has_med_keyword = any(k in symptom_str for k in med_keywords)
                
                if ppe_score < 0.6 or shift_duration > 12.0 or (audio_alert == "Yes" and has_high_keyword):
                    risk_level = "HIGH"
                elif ppe_score < 0.8 or shift_duration > 10.0 or has_high_keyword or has_med_keyword:
                    risk_level = "MEDIUM"
                else:
                    risk_level = "LOW"
                
                # Vary confidence score slightly
                confidence = float(0.85 + (0.14 * (1.0 - ppe_score)))
                if confidence > 0.99: confidence = 0.98
            
            # Add to history list in session
            current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            st.session_state.prediction_history.insert(0, {
                "worker_id": w_id,
                "age": age,
                "department": department,
                "shift_duration_hrs": shift_duration,
                "ppe_compliance_score": ppe_score,
                "audio_alert_flag": audio_alert,
                "reported_symptoms": reported_symptoms if reported_symptoms.strip() else "none",
                "risk_level": risk_level,
                "timestamp": current_time
            })
            
            # Update Live Logs
            st.session_state.live_logs.insert(0, f"[{current_time[11:]}] INFERENCE: Worker {w_id} predicted as {risk_level} RISK (Confidence {confidence*100:.1f}%).")
            
            # ------------------------------------------------
            # PREDICTION DISPLAY PANELS
            # ------------------------------------------------
            st.markdown("<br><h3>📊 Assessment Report Output</h3>", unsafe_allow_html=True)
            
            c_card, c_gauge = st.columns([3, 2], gap="large")
            
            with c_card:
                if risk_level == "LOW":
                    st.markdown(
                        f"""
                        <div class="alert-panel alert-low">
                            <h4>🟢 LOW OPERATIONAL RISK LEVEL</h4>
                            <p style="font-size:1.1rem; margin-top:10px;">Inference Confidence Rating: <b>{confidence*100:.1f}%</b></p>
                            <p><b>Recommended Action</b>: Worker is cleared for regular duty. Keep monitoring regular safety metrics.</p>
                            <p><b>Medical Insight</b>: Vital indicators and symptoms are stable. No immediate fatigue patterns identified.</p>
                            <p><b>Supervisor Notice</b>: Routine log completed. Normal operation status.</p>
                        </div>
                        """,
                        unsafe_allow_html=True
                    )
                elif risk_level == "MEDIUM":
                    st.markdown(
                        f"""
                        <div class="alert-panel alert-medium">
                            <h4>🟡 MEDIUM OPERATIONAL RISK LEVEL</h4>
                            <p style="font-size:1.1rem; margin-top:10px;">Inference Confidence Rating: <b>{confidence*100:.1f}%</b></p>
                            <p><b>Recommended Action</b>: Restrict heavy machinery operation. Verify PPE and assign to a ventilated workspace.</p>
                            <p><b>Medical Insight</b>: Mild symptoms are present (fatigue or discomfort). Scheduled break and re-hydration required.</p>
                            <p><b>Supervisor Notice</b>: Direct supervision advised during the next 4 hours. Record symptoms update before shift end.</p>
                        </div>
                        """,
                        unsafe_allow_html=True
                    )
                else:  # HIGH
                    st.markdown(
                        f"""
                        <div class="alert-panel alert-high">
                            <h4>🔴 CRITICAL HIGH OPERATIONAL RISK LEVEL</h4>
                            <p style="font-size:1.1rem; margin-top:10px;">Inference Confidence Rating: <b>{confidence*100:.1f}%</b></p>
                            <p><b>Recommended Action</b>: IMMEDIATE STOP WORK. Remove worker from site floor and move to a climate-controlled rest station.</p>
                            <p><b>Medical Insight</b>: Acute heat, cardiac, or exhaustion symptoms detected. Alert site medical responder for active check.</p>
                            <p><b>Supervisor Notice</b>: Safety Incident log generated. Alert sent to Health & Safety Director. Escalation code: <b>ESC-RED-450</b>.</p>
                        </div>
                        """,
                        unsafe_allow_html=True
                    )
            
            with c_gauge:
                # Gauge representation of risk level
                risk_numeric_val = 20 if risk_level == "LOW" else (60 if risk_level == "MEDIUM" else 90)
                fig_res = go.Figure(go.Indicator(
                    mode = "gauge+number",
                    value = risk_numeric_val,
                    title = {'text': "Calculated Risk Score (Index)"},
                    gauge = {
                        'axis': {'range': [0, 100]},
                        'bar': {'color': "#ff0055" if risk_level == "HIGH" else ("#ff7b00" if risk_level == "MEDIUM" else "#00ff88")},
                        'bgcolor': "rgba(0,0,0,0)",
                        'steps': [
                            {'range': [0, 40], 'color': 'rgba(0, 255, 136, 0.1)'},
                            {'range': [40, 75], 'color': 'rgba(255, 123, 0, 0.1)'},
                            {'range': [75, 100], 'color': 'rgba(255, 0, 85, 0.1)'}
                        ],
                    }
                ))
                fig_res.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', margin=dict(t=50, b=20, l=10, r=10), font={'color': "white", 'family': "Outfit"})
                st.plotly_chart(fig_res, use_container_width=True)

    st.markdown("</div>", unsafe_allow_html=True)

# ------------------------------------------------
# TAB 3: LIVE MONITORING
# ------------------------------------------------
elif tab_selection == "Live Monitoring":
    st.markdown("<div class='glass-card'><h3>📡 Live Industrial Operational Stream</h3>", unsafe_allow_html=True)
    
    col_stat, col_log = st.columns([1, 2], gap="large")
    
    with col_stat:
        st.write("<b>Active Site Indicators</b>")
        st.markdown(
            """
            <div style='background:rgba(255,255,255,0.02); padding:15px; border-radius:8px; border:1px solid rgba(255,255,255,0.04);'>
                <div style='margin-bottom:12px;'><span class="status-dot dot-active"></span> <b>Welding Unit:</b> Normal</div>
                <div style='margin-bottom:12px;'><span class="status-dot dot-active"></span> <b>Boiler Room:</b> Normal</div>
                <div style='margin-bottom:12px;'><span class="status-dot dot-warning"></span> <b>Foundry:</b> Increased Risk Alerts (2)</div>
                <div style='margin-bottom:12px;'><span class="status-dot dot-active"></span> <b>Chemical Processing:</b> Safe</div>
                <div style='margin-bottom:12px;'><span class="status-dot dot-active"></span> <b>Logistics Yard:</b> Normal</div>
            </div>
            """,
            unsafe_allow_html=True
        )
        
        # Simulate button to trigger new logs
        st.markdown("<br>", unsafe_allow_html=True)
        if st.button("🔄 Poll Live Sensors / Update Telemetry"):
            current_time = datetime.datetime.now().strftime("%H:%M:%S")
            sensor_msg = f"[{current_time}] TELEMETRY: Updated sensor feed. Core temperature of Foundry is stable. PPE ratings verified."
            st.session_state.live_logs.insert(0, sensor_msg)
            st.rerun()

    with col_log:
        st.write("<b>Consolidated Live Event Logger</b>")
        # Format list to log structure
        log_html = "".join([f"<div>{l}</div>" for l in st.session_state.live_logs])
        st.markdown(f"<div class='terminal-output' style='height: 300px;'>{log_html}</div>", unsafe_allow_html=True)
        
    st.markdown("<br><h4>🏭 Multimodal Stream Analytics</h4>", unsafe_allow_html=True)
    
    col_a, col_b = st.columns(2)
    with col_a:
        # Gauge compliance
        fig_rt1 = go.Figure()
        fig_rt1.add_trace(go.Indicator(
            mode = "number+delta",
            value = 93.4,
            delta = {'position': "top", 'reference': 91.2, 'relative': True},
            title = {"text": "Overall PPE Compliance Ingestion"},
            domain = {'x': [0, 1], 'y': [0, 1]}
        ))
        fig_rt1.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', height=180, font={'color': "white", 'family': "Outfit"})
        st.plotly_chart(fig_rt1, use_container_width=True)
        
    with col_b:
        fig_rt2 = go.Figure()
        fig_rt2.add_trace(go.Indicator(
            mode = "number+delta",
            value = 1.05,
            delta = {'position': "top", 'reference': 1.45, 'relative': False},
            title = {"text": "Average Inference Latency (ms)"},
            domain = {'x': [0, 1], 'y': [0, 1]}
        ))
        fig_rt2.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', height=180, font={'color': "white", 'family': "Outfit"})
        st.plotly_chart(fig_rt2, use_container_width=True)
        
    st.markdown("</div>", unsafe_allow_html=True)

# ------------------------------------------------
# TAB 4: ANALYTICS SUITE
# ------------------------------------------------
elif tab_selection == "Analytics Suite":
    st.markdown("<div class='glass-card'><h3>📊 Enterprise Analytics & Historical Risk Suite</h3>", unsafe_allow_html=True)
    
    st.write("Cross-sectional study of telemetry parameters, worker shift characteristics, and historical safety infractions.")
    
    col_an1, col_an2 = st.columns(2)
    
    with col_an1:
        # Plot 1: Worker Fatigue (Shift hours) vs PPE Score
        df_history = pd.DataFrame(st.session_state.prediction_history)
        fig_fatigue = px.scatter(
            df_history,
            x='shift_duration_hrs',
            y='ppe_compliance_score',
            color='risk_level',
            size='age',
            hover_data=['department', 'reported_symptoms'],
            title='Worker Fatigue Matrix (Shift Hours vs. PPE Compliance)',
            color_discrete_map={'LOW': '#00ff88', 'MEDIUM': '#ff7b00', 'HIGH': '#ff0055'},
            template='plotly_dark'
        )
        fig_fatigue.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', margin=dict(t=50, b=20, l=10, r=10))
        st.plotly_chart(fig_fatigue, use_container_width=True)
        
    with col_an2:
        # Plot 2: Risk distribution in departments
        fig_dist = px.bar(
            df_history,
            x='department',
            color='risk_level',
            title='Calculated Safety Incident Levels by Sector',
            color_discrete_map={'LOW': '#00ff88', 'MEDIUM': '#ff7b00', 'HIGH': '#ff0055'},
            template='plotly_dark'
        )
        fig_dist.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', margin=dict(t=50, b=20, l=10, r=10))
        st.plotly_chart(fig_dist, use_container_width=True)
        
    col_an3, col_an4 = st.columns(2)
    
    with col_an3:
        # Plot 3: Cumulative timeline density line
        df_history['datetime'] = pd.to_datetime(df_history['timestamp'])
        df_history_sorted = df_history.sort_values('datetime')
        
        fig_line = px.line(
            df_history_sorted,
            x='timestamp',
            y='ppe_compliance_score',
            markers=True,
            title='PPE Compliance Rating Telemetry Trend over Time',
            template='plotly_dark'
        )
        fig_line.update_traces(line_color='#00f0ff')
        fig_line.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', margin=dict(t=50, b=20, l=10, r=10))
        st.plotly_chart(fig_line, use_container_width=True)
        
    with col_an4:
        # Plot 4: Symptom severity word-density simulation (categorized)
        symptoms_categories = ['heat exhaust', 'back strain', 'breathing issue', 'minor rash', 'none / normal']
        counts = [15, 24, 8, 12, 54]
        fig_bar_sym = px.bar(
            x=symptoms_categories,
            y=counts,
            title='Prevalence of Symptom Clusters (Operational History)',
            template='plotly_dark'
        )
        fig_bar_sym.update_traces(marker_color='#ff7b00')
        fig_bar_sym.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', margin=dict(t=50, b=20, l=10, r=10))
        st.plotly_chart(fig_bar_sym, use_container_width=True)
        
    st.markdown("</div>", unsafe_allow_html=True)

# ------------------------------------------------
# TAB 5: PREDICTION HISTORY
# ------------------------------------------------
elif tab_selection == "Prediction History":
    st.markdown("<div class='glass-card'><h3>📜 Biometric Safety Prediction History Ledger</h3>", unsafe_allow_html=True)
    
    st.write("Browse and audit all predictions processed during the current session.")
    
    # Check if empty
    if not st.session_state.prediction_history:
        st.info("No records are currently logged in history.")
    else:
        df_history = pd.DataFrame(st.session_state.prediction_history)
        
        # Search & Filter
        search_query = st.text_input("🔍 Search symptoms, worker IDs, or departments", "")
        
        # Apply filter
        if search_query:
            df_filtered = df_history[
                df_history['reported_symptoms'].str.contains(search_query, case=False) |
                df_history['worker_id'].str.contains(search_query, case=False) |
                df_history['department'].str.contains(search_query, case=False)
            ]
        else:
            df_filtered = df_history
            
        # Select columns to display
        display_cols = [
            'timestamp', 'worker_id', 'department', 'age', 
            'shift_duration_hrs', 'ppe_compliance_score', 
            'audio_alert_flag', 'reported_symptoms', 'risk_level'
        ]
        
        # Styled data view
        def highlight_risk(val):
            if val == "HIGH":
                return 'background-color: rgba(255, 0, 85, 0.25); color: #ff3366;'
            elif val == "MEDIUM":
                return 'background-color: rgba(255, 123, 0, 0.25); color: #ffaa66;'
            elif val == "LOW":
                return 'background-color: rgba(0, 255, 136, 0.25); color: #66ffbb;'
            return ''
            
        styled_df = df_filtered[display_cols].style.map(
            highlight_risk, subset=['risk_level']
        )
        
        st.dataframe(styled_df, use_container_width=True, height=350)
        
        # Download data as CSV
        csv_data = df_filtered.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="📥 Export Filtered Safety Ledger (CSV)",
            data=csv_data,
            file_name=f"zentrix_safety_ledger_{datetime.date.today()}.csv",
            mime="text/csv"
        )
        
    st.markdown("</div>", unsafe_allow_html=True)

# ------------------------------------------------
# TAB 6: SYSTEM HEALTH HUB
# ------------------------------------------------
elif tab_selection == "System Health Hub":
    st.markdown("<div class='glass-card'><h3>⚙️ Zentrix Diagnostics & System Health</h3>", unsafe_allow_html=True)
    
    col_health1, col_health2 = st.columns(2)
    
    with col_health1:
        st.write("<b>Node Connectivity Matrices</b>")
        
        fastapi_badge = '<span class="status-dot dot-active"></span> <b style="color:#00ff88;">ONLINE (Port 8000)</b>' if backend_ok else '<span class="status-dot dot-danger"></span> <b style="color:#ff0055;">OFFLINE (Unreachable)</b>'
        
        st.markdown(
            f"""
            <div style='background:rgba(255,255,255,0.02); padding:20px; border-radius:8px; border:1px solid rgba(255,255,255,0.05); margin-bottom:20px;'>
                <div style='margin-bottom:15px; font-size:1.1rem;'><b>FastAPI AI Gateway:</b> {fastapi_badge}</div>
                <div style='margin-bottom:15px; font-size:1.1rem;'><b>Risk Estimation Model (sklearn):</b> <span class="status-dot dot-active"></span> <b style="color:#00ff88;">ACTIVE</b></div>
                <div style='margin-bottom:15px; font-size:1.1rem;'><b>Telemetry Database Connector:</b> <span class="status-dot dot-active"></span> <b style="color:#00ff88;">ESTABLISHED</b></div>
                <div style='margin-bottom:15px; font-size:1.1rem;'><b>Log Streaming Daemon:</b> <span class="status-dot dot-active"></span> <b style="color:#00ff88;">RUNNING</b></div>
                <div style='margin-bottom:0; font-size:1.1rem;'><b>Worker Notification Bus (SMTP):</b> <span class="status-dot dot-active"></span> <b style="color:#00ff88;">STANDBY</b></div>
            </div>
            """,
            unsafe_allow_html=True
        )
        
    with col_health2:
        st.write("<b>Platform Hardware Telemetry</b>")
        st.markdown(
            """
            <div style='background:rgba(255,255,255,0.02); padding:20px; border-radius:8px; border:1px solid rgba(255,255,255,0.05);'>
                <div style='margin-top:0;'><b>GPU/VRAM Usage:</b> 12.4% (Direct3D Shared API)</div>
                <div style='margin-top:12px;'><b>RAM allocation:</b> 1.84 GB / 16.00 GB</div>
                <div style='margin-top:12px;'><b>Average Prediction Ingestion Latency:</b> 1.05 ms</div>
                <div style='margin-top:12px;'><b>FastAPI response response-code:</b> HTTP 200 OK</div>
                <div style='margin-top:12px;'><b>Model signature:</b> <code>risk_predictor_v1.2.8</code></div>
            </div>
            """,
            unsafe_allow_html=True
        )
        
    st.markdown("</div>", unsafe_allow_html=True)

# ------------------------------------------------
# TAB 7: PLATFORM OVERVIEW
# ------------------------------------------------
else:
    st.markdown("<div class='glass-card'><h3>🛡️ About the Zentrix AI platform</h3>", unsafe_allow_html=True)
    
    st.write(
        """
        Zentrix AI is an enterprise safety supervisor dashboard designed to prevent occupational health hazards and monitor 
        industrial regulations dynamically. 
        """
    )
    
    st.markdown(
        """
        #### Key Pillars:
        1. **Multimodal Machine Learning**: Fuses structured worker attributes (shift time, age, PPE scores) with textual NLP features representing reported health symptoms.
        2. **Standardized Regulation Compliance**: Live alerting for safety supervisors when PPE scores drop or risk limits are breached.
        3. **Scalable Microservice Architecture**: The ML code runs inside a clean FastAPI gateway allowing integrations with native mobile apps, smartwatches, and industrial sensors.
        
        #### Pipeline Mechanics:
        - Text processing uses a **TF-IDF Vectorizer** (fitted on tokenized medical terms and symptom datasets).
        - Tabular features are standard-scaled via a **StandardScaler**.
        - Risk predictions are resolved into three states: **LOW**, **MEDIUM**, and **HIGH**.
        """
    )
    
    st.markdown("</div>", unsafe_allow_html=True)

# ------------------------------------------------
# FOOTER
# ------------------------------------------------
st.markdown(
    """
    <div style='text-align: center; margin-top: 50px; padding: 20px; border-top: 1px solid rgba(255, 255, 255, 0.05);'>
        <div style='font-size:0.85rem; color:#64748b;'>Powered by Zentrix AI Architecture</div>
        <div style='font-size:0.75rem; color:#475569; margin-top:5px;'>Industrial Worker Safety & Health Intelligence Platform © 2026. All rights reserved.</div>
    </div>
    """,
    unsafe_allow_html=True
)
